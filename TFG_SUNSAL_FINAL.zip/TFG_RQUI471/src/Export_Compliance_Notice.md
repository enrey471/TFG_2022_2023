EXPORT COMPLIANCE NOTICE
--------------------------

This application does not require export control. It can be distributed
to all users.
